=== Visitor Content Wall ===
Contributors: joshuaalmasin 
Donate link: https://example.com/
Tags: content wall, subscribe to view, sign up to view content
Requires at least: 4.7
Tested up to: 6.0
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Visitor Content Wall can easily block visitors from certain posts that you want to be kept private for just your signed up users. Its as easy as adding a shortcode to the post you want to be private. Shortcode: [visitor-content-wall]


== Screenshots ==

1. Example of the modal that will be displayed to users when a user is not signed up.

